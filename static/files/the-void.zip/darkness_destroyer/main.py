import sys, pygame
import os
pygame.init()
from pygame import Color
from pygame.math import Vector2 as vec 
import numpy as np 
import random
import stars
import planets

size = width, height = 900, 700
speed = [0, 0]
acceleration = [0,0]
black = 0, 0, 0

#screen = pygame.display.set_mode(size)
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
width, height = pygame.display.get_surface().get_size()

player = pygame.image.load(os.path.join('planets', 'black_hole.png'))
player = pygame.transform.scale(player, (60, 60))
playerRect = player.get_rect().move(width/2 - 30, height/2 - 30)

star_array = stars.initialize_stars(400)
planet_array = planets.initialize_planets(10, width, height)

t1 = pygame.time.get_ticks()
t2 = pygame.time.get_ticks()
i=0
while 1:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: sys.exit()

    t1 = pygame.time.get_ticks()
    dt = (t1 - t2) / 1000
    t2 = t1

    state = pygame.key.get_pressed()
    if state[pygame.K_w]:
        acceleration = [0,-7 * dt]
        speed[0] = speed[0] + acceleration[0]
        speed[1] = speed[1] + acceleration[1]
    if state[pygame.K_s]:
        acceleration = [0,7 * dt]
        speed[0] = speed[0] + acceleration[0]
        speed[1] = speed[1] + acceleration[1]
    if state[pygame.K_a]:
        acceleration = [-7 * dt,0]
        speed[0] = speed[0] + acceleration[0]
        speed[1] = speed[1] + acceleration[1]
    if state[pygame.K_d]:
        acceleration = [7 * dt,0]
        speed[0] = speed[0] + acceleration[0]
        speed[1] = speed[1] + acceleration[1]

    #if i == 2:

    planets.step_planets(planet_array, speed, width, height, star_array, dt)

    #    i = 0

    #i = i + 1
    #ballrect = ballrect.move(speed)
    planets.draw_planets(planet_array, screen)
    screen.fill(black)
    stars.draw_stars(star_array, screen)
    planets.draw_planets(planet_array, screen)
    screen.blit(player, playerRect)


    pygame.time.wait(30)
    pygame.display.flip()

 
