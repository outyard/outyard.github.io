




import sys, pygame
import os
pygame.init()
from pygame import Color
from pygame.math import Vector2 as vec 
import numpy as np 
import random
import stars
import math
from builtins import int

planet_list= ["planet_1.png", "planet_2.png", "planet_3.png", "planet_4.png", "planet_5.png", "planet_6.png", "planet_7.png", "planet_8.png", 
              "planet_9.png", "planet_10.png", "planet_11.png", "planet_12.png", "planet_13.png", "planet_14.png", "planet_15.png", "planet_16.png", 
              "planet_17.png", "planet_18.png", "planet_19.png", "planet_20.png"]
max_distance = 5000

def gravitational_force(G, planet, width, height):
    planet_center_x = planet.x + planet.size/2
    planet_center_y = planet.y + planet.size/2
    player_center_x = width/2 - 30
    player_center_y = height/2 - 30
    player_mass = (60/2)**2 * math.pi
    planet_mass = (planet.size/2)**2 * math.pi
    seperation = math.sqrt( (planet_center_x - player_center_x)**2 + (planet_center_y - player_center_y)**2 )

    if seperation < 5:
        seperation = 5
    if (player_center_x - planet_center_x) == 0:
        angle = 0
    else:
        angle = math.atan( -(planet_center_y - player_center_y) / -(planet_center_x - player_center_x))
        print(angle*180/math.pi)
    force = (G*player_mass*planet_mass) / seperation**2

    if (planet_center_x < player_center_x):
        force_x = abs(force * math.cos(angle))
    else:
        force_x = -abs(force * math.cos(angle))

    if (planet_center_y < player_center_y):
        force_y = abs(force * math.sin(angle))
    else:
        force_y = -abs(force * math.sin(angle))


    # if force_x/player_mass > 3:
    #     force_x = 3 * player_mass
    # if force_x/player_mass < 3:
    #     force_x = -3 * player_mass
    # if force_y/player_mass > 3:
    #     force_y = 3 * player_mass
    # if force_y/player_mass < 3:
    #     force_y = -3 * player_mass
  

    return (force_x/player_mass, force_y/player_mass)



def step_planets(planet_array, speed, width, height, star_array, dt):

    total_force_x = 0
    total_force_y = 0
    for planet in planet_array:
        forces = gravitational_force(10, planet, width, height)
        total_force_x = total_force_x + forces[0]
        total_force_y = total_force_y + forces[1]
        print("force: " + str(total_force_x) + "," + str(total_force_y))
    speed[0] = speed[0] - total_force_x * dt
    speed[1] = speed[1] - total_force_y * dt

    max_speed = 30
    if speed[0] > max_speed:
        speed[0] = max_speed
    if speed[0] < -max_speed:
        speed[0] = -max_speed
    if speed[1] > max_speed:
        speed[1] = max_speed
    if speed[1] < -max_speed:
        speed[1] = -max_speed

    stars.move_stars(star_array, (int(speed[0]),int(speed[1])) )
    move_planets(planet_array, (int(speed[0]),int(speed[1])))

    planet_update = []
    for i,planet in enumerate(planet_array):
        if planet.x < -planet.max_distance or planet.x > planet.max_distance or planet.y < -planet.max_distance or planet.y > planet.max_distance:
            planet_update.append(i)
    
    for index in planet_update:
        integer = random.randint(0,19)
        r1 = random.randint(0,1)
        r2 = random.randint(0,1)
        if r1:
            x=random.randint(-max_distance, width/2 - 2000)
        else:
            x=random.randint(width/2 + 2000,max_distance)
        if r2:
            y=random.randint(-max_distance, height/2 - 2000)
        else:
            y=random.randint(height/2 + 2000 ,max_distance)

        size = random.randint(30,600)
        planet_array[index] = Planet(x, y, size, pygame.image.load(os.path.join('planets', planet_list[integer])))



def move_planets(planet_array, speed):
    for planet in planet_array:
        print(str(planet.x) + "," + str(planet.y))
        planet.move(speed)

def draw_planets(planet_array, screen):
    for planet in planet_array:
        screen.blit(planet.planet_object, planet.planet_rect)

def initialize_planets(number_of_planets, width, height):
    planet_array = []
    for _ in range(number_of_planets):
        int = random.randint(0,19)
        size = random.randint(40,100)
        #x=random.randint(-max_distance, max_distance)
        #y=random.randint(-max_distance, max_distance)
        looking_for_position = True
        while looking_for_position:
            looking_for_position = False
            r1 = random.randint(0,1)
            r2 = random.randint(0,1)
            if r1:
                x=random.randint(-max_distance, width/2 - 300)
            else:
                x=random.randint(width/2 + 300,max_distance)
            if r2:
                y=random.randint(-max_distance, height/2 - 300)
            else:
                y=random.randint(width/2 + 300 ,max_distance)

            #for planet in planet_array:
            #    if x 

                
        planet_array.append(Planet(x, y, size, pygame.image.load(os.path.join('planets', planet_list[int]))))
        #star_array.append(Star(x,y, max_distance))
    return planet_array




class Planet():

    def __init__(self, x, y, size, planet_object):
        self.x = x
        self.y = y
        self.max_distance = max_distance
        self.planet_object = planet_object
        self.size = size
        self.planet_object = pygame.transform.scale(self.planet_object, (size, size))
        self.planet_rect = self.planet_object.get_rect()
        self.planet_rect.move_ip(x,y)


    def move(self, speed):
        self.x = self.x - speed[0]
        self.y = self.y - speed[1]


        self.planet_rect.move_ip(-speed[0],-speed[1])



        
