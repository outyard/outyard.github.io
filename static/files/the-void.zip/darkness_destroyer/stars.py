import sys, pygame
import os
pygame.init()
from pygame import Color
from pygame.math import Vector2 as vec 
import numpy as np 
import random

def move_stars(star_array, speed):
    for star in star_array:
        star.move(speed)

def draw_stars(star_array, screen):
    for star in star_array:
        pygame.draw.circle(screen, Color(255,255,255), (star.x,star.y), 2)

def initialize_stars(number_of_stars):
    star_array = []
    for _ in range(number_of_stars):
        x = random.randint(-Star(0,0).max_distance,Star(0,0).max_distance)
        y = random.randint(-Star(0,0).max_distance,Star(0,0).max_distance)
        star_array.append(Star(x,y))


    return star_array


class Star():

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.max_distance = 2500


    def move(self, speed):
        self.x = self.x - speed[0]
        self.y = self.y - speed[1]

        if self.x < -self.max_distance:
            self.x = self.x + self.max_distance * 2
        if self.x > self.max_distance:
            self.x = self.x - self.max_distance * 2
        if self.y < -self.max_distance:
            self.y = self.y + self.max_distance * 2
        if self.y > self.max_distance:
            self.y = self.y - self.max_distance * 2


